package org.opencv;

public class BuildConfig {
	public static boolean DEBUG=true;
}
