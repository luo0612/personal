/** Automatically generated file. DO NOT MODIFY */
package com.example.opencvmanager;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}