package com.example.facecheckdemo.bean;


public class Add {

	public long log_id;	

	public int error_code;
	
	public String error_msg;

	@Override
	public String toString() {
		return "Add [log_id=" + log_id + ", error_code=" + error_code
				+ ", error_msg=" + error_msg + "]";
	}
	
	
	
	

}
