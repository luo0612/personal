package com.example.facecheckdemo.activity;

import com.example.facecheckdemo.R;

import android.app.Activity;
import android.os.Bundle;







public class DealSuccessActivity extends Activity  {
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}
	
	
	
	
	
	
}
