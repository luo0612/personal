# project

利用 react-native 构建一个模拟外卖平台的原生APP。


项目暂停一段时间，处理其他事情
