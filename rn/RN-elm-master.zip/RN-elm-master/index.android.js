
import { AppRegistry } from 'react-native';
import setClock from './src/setClock';

AppRegistry.registerComponent('paiband',() => setClock);
